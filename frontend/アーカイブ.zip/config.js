window.KANSA_CONFIG = {
  apiBase: 'https://0nhz8sat7j.execute-api.ap-northeast-1.amazonaws.com',
  photoBucket: 'kansa-backend-photobucket-ufurvgtp4oqi',
  cognitoRegion: 'ap-northeast-1',
  cognitoDomain: 'photohub4kansa',
  cognitoClientId: 'nlpccd2h79jr93rejmiv35eci',
  cognitoRedirectUri: window.location.origin,
};
